package test;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import bean.Price;
import bean.Product;
import service.UserService;

public class Testcases {
	private static final double DELTA = 1e-15;
	@Rule
    public ExpectedException exception = ExpectedException.none();
	   @Test
	   public void testCalculateIdealPrice() {
		   UserService uservice=new UserService();
		   ArrayList<Double> list=new ArrayList<Double>();
		   list.add(1070.0);
		   list.add(1080.0);
		   Product testProduct=new Product();
		   testProduct.setBarcode("product2");
		   testProduct.setPriceList(list);
		   Product product;
		try {
			product = uservice.calculateIdealPrice(testProduct);
			assertEquals(product.getBarcode(),"product2");
			  assertEquals(product.getAvgprice(),1075.0,DELTA);
			  assertEquals(product.getPrice(),1290.0,DELTA);
			  assertEquals(product.getHighprice(),1080.0,DELTA);
			  assertEquals(product.getLowprice(),1070.0,DELTA);
			  assertEquals(product.getTotalprices(),2,DELTA);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   }
	   //check For empty pricelist
	   @Test
	   public void testCalculateIdealPriceNegative() {
		   UserService uservice=new UserService();
		   ArrayList<Double> list=new ArrayList<Double>();
		   Product testProduct=new Product();
		   testProduct.setBarcode("product7");
		   testProduct.setPriceList(list);
		   Product product;
		try {
			product = uservice.calculateIdealPrice(testProduct);
			assertEquals(product.getBarcode(),"product7");
			  assertEquals(product.getAvgprice(),0,DELTA);
			  assertEquals(product.getPrice(),0,DELTA);
			  assertEquals(product.getHighprice(),0,DELTA);
			  assertEquals(product.getLowprice(),0,DELTA);
			  assertEquals(product.getTotalprices(),0,DELTA);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   }
	   @Test
	   public void testCalculateAvgPriceNegative() {
		   UserService uservice=new UserService();
		   ArrayList<Double> list=null;
		   try {
				assertEquals(uservice.calculateAvgPrice(list),0,DELTA);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }
	   @Test(expected = SQLException.class)
	   public void testInsertPrice() throws Exception {
		   UserService uservice=new UserService();
		   Price testPrice=new Price();
		   testPrice.setBarcode("xyz");
		   testPrice.setPrice(2000.0);
		   testPrice.setStoreID("Store1");
		   testPrice.setNotes("Notes");
		   uservice.insertPrice(testPrice);
	   }
	   
}
