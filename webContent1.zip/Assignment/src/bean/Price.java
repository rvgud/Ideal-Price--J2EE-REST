package bean;
public class Price {
	private String storeID;
	private Double price;
	private String notes;
	private String barcode;
	public Double getPrice() {
		return this.price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getBarcode() {
		return this.barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getStoreID() {
		return this.storeID;
	}
	public void setStoreID(String storeID) {
		this.storeID = storeID;
	}
	public String getNotes() {
		return this.notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}

}