package bean;

import java.util.List;

public class Chance {
	private int chanceNo;
	List<Arrow> arrows;
	public int getChanceNo() {
		return chanceNo;
	}
	public void setChanceNo(int chanceNo) {
		this.chanceNo = chanceNo;
	}
	public List<Arrow> getArrows() {
		return arrows;
	}
	public void setArrows(List<Arrow> arrows) {
		this.arrows = arrows;
	}
	
}
