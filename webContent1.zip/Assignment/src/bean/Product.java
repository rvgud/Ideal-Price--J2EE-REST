package bean;

import java.util.ArrayList;

public class Product {
	private String name;
	private String barcode;
	private String description;
	private double price;
	private double avgprice;
	private double lowprice;
	private double highprice;
	private int totalprices;
	public int getTotalprices() {
		return this.totalprices;
	}
	public void setTotalprices(int totalprices) {
		this.totalprices = totalprices;
	}
	private ArrayList<Double> PriceList;
	public double getAvgprice() {
		return this.avgprice;
	}
	public void setAvgprice(double avgprice) {
		this.avgprice = avgprice;
	}
	public double getLowprice() {
		return this.lowprice;
	}
	public void setLowprice(double lowprice) {
		this.lowprice = lowprice;
	}
	public double getHighprice() {
		return this.highprice;
	}
	public void setHighprice(double highprice) {
		this.highprice = highprice;
	}
	public void setPriceList(ArrayList<Double> list) {
		PriceList = list;
	}
	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBarcode() {
		return this.barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return this.price;
	}
	public void setPrice(double avg) {
		this.price = avg;
	}
	public ArrayList getPriceList() {
		return this.PriceList;
	}
	
}