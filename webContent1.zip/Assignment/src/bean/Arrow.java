package bean;

public class Arrow {
	private int arrowId;
	private int value;
	public int getArrowId() {
		return arrowId;
	}
	public void setArrowId(int arrowId) {
		this.arrowId = arrowId;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
}
