package API;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

//Git
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import service.ScoreService;
import service.UserService;
import bean.Chance;
import bean.Price;
import bean.Product;
import bean.User;

@Path("/Users")
public class Client {
	
	@POST
	@Path("/Products")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getAllProducts(String datarecieved) throws Exception{
		Response response=null;
		Gson g = new Gson();
		try{
			UserService uservice=new UserService();
			List<Product> products=uservice.getAllProducts();
			String returnString=g.toJson(products);
			response=Response.ok(returnString).build();
		}
		catch(Exception e){
			String returnString=g.toJson(e.getMessage());
			response=Response.status(400).entity(returnString).build();
		}
		
		return response;
	}
	@POST
	@Path("/ProductByBarcode")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getProductByBarcode(String datarecieved) throws Exception{
		Response response=null;
		Gson g = new Gson();
		Product product=g.fromJson(datarecieved, Product.class);
		try{
			UserService uservice=new UserService();
			product=uservice.getProductByBarCode(product);
			String returnString=g.toJson(product);
			System.out.println(returnString);
			response=Response.ok(returnString).build();
		}
		catch(Exception e){
			String returnString=g.toJson(e.getMessage());
			//response=Response.ok(returnString).build();
			response=Response.status(400).entity(returnString).build();
		}
		return response;
	}
	@POST
	@Path("/Score")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response insertPrice(String datarecieved) throws Exception{
		Response response=null;
		Gson g = new Gson();
		System.out.println(datarecieved);
		Type chancetype = new TypeToken<ArrayList<Chance>>(){}.getType(); 
		ArrayList<Chance> chances=g.fromJson(datarecieved, chancetype);
		System.out.println(chances.size());
		try{
			ScoreService sservice=new ScoreService();
			sservice.getScore(chances);
			String returnString="Price inserted succesfully";
			response=Response.ok(g.toJson(returnString)).build();
		}
		catch(Exception e){
			String returnString="Price not inserted! Please try Again.";
			response=Response.status(400).entity(g.toJson(returnString)).build();
		}
		return response;
	}
	
}