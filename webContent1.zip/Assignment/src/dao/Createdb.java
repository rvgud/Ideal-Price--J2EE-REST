package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import bean.Product;
import bean.Price;
import bean.User;

public class Createdb {
	private static final String DRIVER="org.h2.Driver";
	private static final String DB_PATH = "jdbc:h2:./Database/user";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "1234";
	private static Createdb instance=null;
	
	protected Createdb() throws ClassNotFoundException, SQLException {
		DbConnection.createTables();
	   }
	
	public static Createdb getInstance() throws ClassNotFoundException, SQLException {
	      if(instance == null) {
	    	  instance = new Createdb();
	      }
	      return instance;
	   }
	
	
	
	
	public void insertPrice(Price store) throws SQLException, ClassNotFoundException {
		Connection dbconnection=DbConnection.createdbconnection();
		try {
			dbconnection.setAutoCommit(false);
			PreparedStatement stmt= dbconnection.prepareStatement("INSERT INTO price VALUES(?,?,?,?)");
			stmt.setString(1, store.getBarcode());
			stmt.setString(2, store.getStoreID());
			stmt.setDouble(3, store.getPrice());
			stmt.setString(4, store.getNotes());
			stmt.execute();
			stmt.close();
			dbconnection.commit();
		}catch (SQLException e){
			throw e;
		}
		finally {
			dbconnection.close();
		}
	}
	public Product getProductByBarCode(Product product) throws Exception {
		Connection dbconnection=DbConnection.createdbconnection();
		ArrayList<Double> list=new ArrayList<Double>();
		try {
			dbconnection.setAutoCommit(false);
			PreparedStatement stmt= dbconnection.prepareStatement("SELECT * from product where barcode=?");
			stmt.setString(1, product.getBarcode());
			ResultSet rs =stmt.executeQuery();
			if(rs.next()){
				product.setName(rs.getString("name"));
				product.setDescription(rs.getString("description"));
				stmt= dbconnection.prepareStatement("SELECT DISTINCT price from price where barcode=?");
				stmt.setString(1, product.getBarcode());
				rs =stmt.executeQuery();
				while(rs.next()){
					list.add(rs.getDouble("price"));
				}
				product.setPriceList(list);
			}
			else {
				Exception e=new Exception("Bar Code doesn't exists.");
				throw e;
			}
			
			stmt.close();
			dbconnection.commit();
			return product;
		}catch (SQLException e){
			throw e;
		}
		finally {
			dbconnection.close();
		}
	}
	public ArrayList<Product> getAllProduct() throws Exception {
		Connection dbconnection=DbConnection.createdbconnection();
		ArrayList<Product> list=new ArrayList<Product>();
		try {
			dbconnection.setAutoCommit(false);
			PreparedStatement stmt= dbconnection.prepareStatement("SELECT * from product");
			ResultSet rs =stmt.executeQuery();
			while(rs.next()){
				Product product=new Product();
				product.setBarcode(rs.getString("barcode"));
				product.setDescription(rs.getString("description"));
				product.setName(rs.getString("name"));
				list.add(product);
			}
			stmt.close();
			dbconnection.commit();
			return list;
		}catch (SQLException e){
			throw e;
		}
		finally {
			dbconnection.close();
		}
	}
	public ArrayList<Product> getProducts(int pageno) throws Exception {
		Connection dbconnection=DbConnection.createdbconnection();
		ArrayList<Product> list=new ArrayList<Product>();
		try {
			dbconnection.setAutoCommit(false);
			PreparedStatement stmt= dbconnection.prepareStatement("SELECT * from product");
			ResultSet rs =stmt.executeQuery();
			while(rs.next()){
				Product product=new Product();
				product.setBarcode(rs.getString("barcode"));
				product.setDescription(rs.getString("description"));
				product.setName(rs.getString("name"));
				list.add(product);
			}
			stmt.close();
			dbconnection.commit();
			return list;
		}catch (SQLException e){
			throw e;
		}
		finally {
			dbconnection.close();
		}
	}
	
}
