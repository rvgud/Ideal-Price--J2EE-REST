package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import bean.Product;
import bean.User;
import service.UserService;

public class DbConnection {
	private static final String DRIVER="org.h2.Driver";
	private static final String DB_PATH = "jdbc:h2:./Database/user";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "1234";
	   public static Connection createdbconnection() throws ClassNotFoundException, SQLException {

			Connection dbconnection=null;
			try {
				Class.forName(DRIVER);
			} 
			catch(ClassNotFoundException e) {
				throw e;
			}
			try {
				
					dbconnection=DriverManager.getConnection(DB_PATH, DB_USER,DB_PASSWORD);
			      
				
			} catch (SQLException e){
				throw e;
			}
			return dbconnection;
		   }
	
	   public static void createTables() throws SQLException, ClassNotFoundException{
		   Connection connection=createdbconnection();
			Statement stmt =null;
			try {
				connection.setAutoCommit(false);
				stmt =connection.createStatement();
				
					stmt.execute("DROP TABLE IF EXISTS product");
					stmt.execute("DROP TABLE IF EXISTS price");
					stmt.execute("CREATE TABLE  product(barcode varchar(255) primary key,name varchar(255),description varchar(255))");
					stmt.execute("CREATE TABLE  price(barcode varchar(255) ,store varchar(255), price double,notes varchar(255), FOREIGN KEY (barcode) REFERENCES product(barcode))");
					stmt.execute("INSERT INTO product VALUES('product1','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product2','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product3','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product4','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product5','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product6','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product7','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product8','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product9','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product10','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product11','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product12','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product13','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product14','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product15','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product16','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product17','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO product VALUES('product18','Demo Product','Product Description Demo')");
					stmt.execute("INSERT INTO price VALUES('product1','Store1',1000,'Store1 Price')");
					stmt.execute("INSERT INTO price VALUES('product1','Store2',800,'Store2 Price')");
					stmt.execute("INSERT INTO price VALUES('product1','Store3',900,'Store3 Price')");
					stmt.execute("INSERT INTO price VALUES('product1','Store4',1100,'Store4 Price')");
					stmt.execute("INSERT INTO price VALUES('product1','Store4',1100,'Store4 Price')");
					stmt.execute("INSERT INTO price VALUES('product1','Store4',1100,'Store4 Price')");
					stmt.execute("INSERT INTO price VALUES('product1','Store4',1100,'Store4 Price')");
					stmt.execute("INSERT INTO price VALUES('product1','Store4',1050,'Store5 Price')");
					stmt.execute("INSERT INTO price VALUES('product2','Store1',1080,'Store1 Price')");
					stmt.execute("INSERT INTO price VALUES('product2','Store2',1070,'Store2 Price')");
					stmt.execute("INSERT INTO price VALUES('product3','Store1',1070,'Store1 Price')");
					stmt.execute("INSERT INTO price VALUES('product3','Store2',1090,'Store2 Price')");
					stmt.execute("INSERT INTO price VALUES('product4','Store1',1100,'Store1 Price')");
					stmt.execute("INSERT INTO price VALUES('product4','Store2',1040,'Store2 Price')");
				
				stmt.close();
				connection.commit();
			}
			catch (SQLException e) {
				throw e;
			}
			finally {
				connection.close();
			}
		}
	   public static void showdata() throws Exception {
			Connection dbconnection=createdbconnection();
			Statement stmt=null;
			try {
				dbconnection.setAutoCommit(false);
				stmt=dbconnection.createStatement();
				ResultSet rs =stmt.executeQuery("select * from product");
				while(rs.next()){
					System.out.println("Name:-" + rs.getString("name")+"Bar Code:-"+rs.getString("barcode")+"Description:-"+rs.getString("description"));
				}
				rs =stmt.executeQuery("select * from price");
				while(rs.next()){
					System.out.println("Bar Code:-" + rs.getString("barcode")+"Store:-"+rs.getString("store")+"price:-"+rs.getString("price")+"Notes:-"+rs.getString("notes"));
				}
				stmt.close();
				dbconnection.commit();
			}catch (SQLException e){
				System.out.println("Exception message " + e.getLocalizedMessage());
			}catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				dbconnection.close();
			}
		}
	   
}
