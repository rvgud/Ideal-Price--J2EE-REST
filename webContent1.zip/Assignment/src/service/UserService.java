package service;
import java.util.ArrayList;
import java.util.Collections;

import bean.Price;
import bean.Product;
import dao.Createdb;
public class UserService {
	public ArrayList<Product> getAllProducts() throws Exception{
		ArrayList<Product> list=new ArrayList<Product>();
		Createdb db=Createdb.getInstance();
		list=db.getAllProduct();
		return list;
	}
	public ArrayList<Product> getProducts(int pageno) throws Exception{
		ArrayList<Product> list=new ArrayList<Product>();
		Createdb db=Createdb.getInstance();
		list=db.getProducts(pageno);
		return list;
	}
	public Product getProductByBarCode(Product product) throws Exception{
		Createdb db=Createdb.getInstance();
		product=db.getProductByBarCode(product);
		product=this.calculateIdealPrice(product);
		return product;
	}
	public Product calculateIdealPrice(Product product) throws Exception{
		//Original list
		ArrayList<Double> pricelist=product.getPriceList();
		if(pricelist.size()>0) {
			product.setTotalprices(pricelist.size());
			Collections.sort(pricelist);
			product.setAvgprice(this.calculateAvgPrice(pricelist));
			product.setHighprice(pricelist.get(pricelist.size()-1));
			product.setLowprice(pricelist.get(0));
			//Removing 2 Highest and 2 lowest from list
			if(pricelist.size()>4) {
				pricelist.remove(pricelist.size()-1);
				pricelist.remove(pricelist.size()-1);
				pricelist.remove(0);
				pricelist.remove(0);
			}
			//Average of list
			double avg=this.calculateAvgPrice(pricelist);
			//Ideal Price of list
			avg=avg+(avg*0.2);
			product.setPrice(avg);
		}
		else {
			product.setAvgprice(0);
			product.setHighprice(0);
			product.setLowprice(0);
			product.setPrice(0);
			product.setTotalprices(0);
		}
		return product;
	}
	public double calculateAvgPrice(ArrayList<Double> pricelist) throws Exception{
		double sum=0;
		if(pricelist!=null) {
			for (Double i : pricelist) {
				sum+=i;
			}
			sum=sum/pricelist.size();
		}
		return sum;
	}
	public void insertPrice(Price store) throws Exception{
		Createdb db=Createdb.getInstance();
		db.insertPrice( store);
	}
	
}
