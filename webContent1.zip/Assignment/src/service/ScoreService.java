package service;

import java.util.ArrayList;

import bean.Chance;

public class ScoreService {

	public void getScore(ArrayList<Chance> chances) {
		// TODO Auto-generated method stub
		
	}

}
