 var URI=getURI;
 var assignment = angular.module("Application", ['ngCookies']);
 assignment.config(function($httpProvider){
 	$httpProvider.defaults.headers.post['Content-Type']="application/json; charset=UTF-8";
 	$httpProvider.defaults.headers.post["Data-Type"]="json";

 });
 assignment.controller(
			"mainController",
		function($scope,$http,$cookies){
			}
			);
 assignment.controller(
			"HomeController",
		function($scope,$http,$cookies){
				$scope.admin=true;
				$scope.products=[];
				$scope.product={};
				$scope.form={};
				$scope.submitform=function(){
					var data=angular.toJson($scope.form);
					var responsePromise=$http.post(URI+"Price",data);
					responsePromise.then(
					function(response){
						$scope.form={};
						$scope.form.message=response.data;
					},
					function(response){
						$scope.form.message=response.data;
					}
					);
				}
				
				$scope.getProducts=function(){
					$scope.score="tyu";
					console.log($scope.score);
					var responsePromise=$http.post(URI+"Products");
					responsePromise.then(
					function(response){
						console.log(response);
						$scope.products=response.data;
					},
					function(response){
						$scope.loginForm.message=response.data.message;
					}
					);
				}
				$scope.getProductByBarcode=function(barcode){
					$scope.product={};
					$scope.product.barcode=barcode;
					var data=angular.toJson($scope.product);
					console.log(data);
					var responsePromise=$http.post(URI+"ProductByBarcode",data);
					responsePromise.then(
					function(response){
						console.log(response);
						if(response.data.price==0)
							response.data.price="NA";
						if(response.data.avgprice==0)
							response.data.avgprice="NA";
						if(response.data.highprice==0)
							response.data.highprice="NA";
						if(response.data.lowprice==0)
							response.data.lowprice="NA";
						$scope.product=response.data;
						$scope.showModal=true;
						$scope.message=null;
					},
					function(response){
						$scope.showModal=false;
						$scope.message=response.data;
					}
					);
				}
			});