 var URI=getURI;
 var assignment = angular.module("Application", ['ngCookies']);
 assignment.config(function($httpProvider){
 	$httpProvider.defaults.headers.post['Content-Type']="application/json; charset=UTF-8";
 	$httpProvider.defaults.headers.post["Data-Type"]="json";

 });